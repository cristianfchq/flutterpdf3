package com.sidlatau.flutteremailsender

import androidx.core.content.FileProvider

class FlutterEmailSenderFileProvider : FileProvider()